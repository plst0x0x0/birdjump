use tauri::{
    AppHandle, Manager, Runtime, SystemTray, SystemTrayEvent, SystemTrayMenu,
    CustomMenuItem, SystemTrayMenuItem,
};

// ── Tauri commands ──────────────────────────────────────────────

/// Show the main search / hotkey window
#[tauri::command]
async fn show_main_window(app: AppHandle) {
    if let Some(win) = app.get_webview_window("main") {
        let _ = win.show();
        let _ = win.set_focus();
    }
}

/// Hide the main window
#[tauri::command]
async fn hide_main_window(app: AppHandle) {
    if let Some(win) = app.get_webview_window("main") {
        let _ = win.hide();
    }
}

/// Show the settings window
#[tauri::command]
async fn show_settings_window(app: AppHandle) {
    if let Some(win) = app.get_webview_window("main") {
        let _ = win.show();
        let _ = win.set_focus();
        let _ = win.emit("open-settings", ());
    }
}

/// Get clipboard text content
#[tauri::command]
async fn get_clipboard_text() -> Result<String, String> {
    // In production: use tauri-plugin-clipboard-manager
    Ok(String::new())
}

/// Open a URL in the default browser
#[tauri::command]
async fn open_url(url: String, app: AppHandle) -> Result<(), String> {
    use tauri_plugin_opener::OpenerExt;
    app.opener()
        .open_url(&url, None::<&str>)
        .map_err(|e| e.to_string())
}

/// Quit the application
#[tauri::command]
async fn quit_app(app: AppHandle) {
    app.exit(0);
}

// ── App entry point ─────────────────────────────────────────────

#[cfg_attr(mobile, tauri::mobile_entry_point)]
pub fn run() {
    tauri::Builder::default()
        .plugin(tauri_plugin_opener::init())
        // Global shortcut plugin — register hotkey at runtime from JS side
        // .plugin(tauri_plugin_global_shortcut::Builder::new().build())
        // Clipboard manager
        // .plugin(tauri_plugin_clipboard_manager::init())
        // Autostart at login
        // .plugin(tauri_plugin_autostart::init(tauri_plugin_autostart::MacosLauncher::LaunchAgent, Some(vec![])))
        .invoke_handler(tauri::generate_handler![
            show_main_window,
            hide_main_window,
            show_settings_window,
            get_clipboard_text,
            open_url,
            quit_app,
        ])
        .setup(|app| {
            // Hide from dock on macOS — it's a menu-bar app
            #[cfg(target_os = "macos")]
            {
                use tauri::ActivationPolicy;
                app.set_activation_policy(ActivationPolicy::Accessory);
            }
            Ok(())
        })
        .run(tauri::generate_context!())
        .expect("error while running BirdJump");
}
