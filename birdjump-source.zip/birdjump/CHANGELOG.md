# Changelog

All notable changes to BirdJump will be documented in this file.

## [Unreleased]

## [0.1.0] - Initial Release

### Added
- Hotkey-triggered search window with real-time results
- App launching (macOS, Windows, Linux)
- File search with Open, Find, Inside, Tags keywords
- File Search Buffer (multi-file selection via ⌥ key)
- File Search Navigation mode with fuzzy matching
- Clipboard History with configurable retention per type (plain text, images, file lists)
- Snippets with collections, keywords, and import/export
- Web Search with 20 built-in providers + custom search support
- Built-in calculator (arithmetic, trig, log, constants)
- AI integration (OpenAI / Anthropic)
- Settings window (General, Features, AI tabs)
- Hotkey recorder with macOS symbols (⌘ ⌃ ⌥ ⇧)
- Menu bar icon
- Persistent settings via localStorage
- GitHub Actions CI/CD for macOS, Windows, and Linux
