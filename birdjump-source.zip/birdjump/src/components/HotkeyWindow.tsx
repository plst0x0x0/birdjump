import { useState, useEffect, useRef, useCallback } from 'react';
import { Search, ArrowRight } from 'lucide-react';
import { useAppStore } from '../store';
import type { SearchResult } from '../types';
import type { WebSearchEntry } from '../types';

function evaluate(expr: string): string | null {
  try {
    const sanitized = expr
      .replace(/\^/g, '**')
      .replace(/sqrt\(/g, 'Math.sqrt(')
      .replace(/sin\(/g, 'Math.sin(')
      .replace(/cos\(/g, 'Math.cos(')
      .replace(/tan\(/g, 'Math.tan(')
      .replace(/log\(/g, 'Math.log10(')
      .replace(/ln\(/g, 'Math.log(')
      .replace(/\bpi\b/g, 'Math.PI')
      .replace(/\be\b/g, 'Math.E');
    // eslint-disable-next-line no-new-func
    const result = Function('"use strict"; return (' + sanitized + ')')();
    if (typeof result === 'number' && isFinite(result)) {
      return String(Math.round(result * 1e10) / 1e10);
    }
    return null;
  } catch {
    return null;
  }
}

function getMockResults(query: string, webSearches: WebSearchEntry[]): SearchResult[] {
  if (!query.trim()) return [];

  const results: SearchResult[] = [];

  // Calculator
  const calcResult = evaluate(query);
  if (calcResult !== null) {
    results.push({
      id: 'calc',
      type: 'calculator',
      title: calcResult,
      subtitle: `= ${query}`,
      icon: '🔢',
      iconType: 'emoji',
    });
  }

  // Web searches — match keyword prefix
  const firstWord = query.toLowerCase().split(' ')[0];
  const queryRest = query.split(' ').slice(1).join(' ');
  const matchedSearches = webSearches.filter(
    (e) => e.enabled && e.keyword.toLowerCase().startsWith(firstWord) && firstWord.length >= 2
  );
  matchedSearches.slice(0, 3).forEach((entry) => {
    results.push({
      id: `web-${entry.id}`,
      type: 'web',
      title: entry.displayText.replace('{query}', queryRest || '...'),
      subtitle: entry.url.replace('{query}', queryRest || ''),
      icon: '🌐',
      iconType: 'emoji',
    });
  });

  // Mock apps
  const mockApps = [
    { name: 'Safari', icon: '🧭', path: '/Applications/Safari.app' },
    { name: 'Terminal', icon: '⬛', path: '/Applications/Utilities/Terminal.app' },
    { name: 'Finder', icon: '🔍', path: '/System/Library/CoreServices/Finder.app' },
    { name: 'System Preferences', icon: '⚙️', path: '/System/Applications/System Preferences.app' },
    { name: 'Calculator', icon: '🔢', path: '/System/Applications/Calculator.app' },
    { name: 'TextEdit', icon: '📝', path: '/System/Applications/TextEdit.app' },
    { name: 'Notes', icon: '📒', path: '/System/Applications/Notes.app' },
    { name: 'Calendar', icon: '📅', path: '/System/Applications/Calendar.app' },
    { name: 'Mail', icon: '✉️', path: '/System/Applications/Mail.app' },
    { name: 'Photos', icon: '🖼', path: '/System/Applications/Photos.app' },
    { name: 'Music', icon: '🎵', path: '/System/Applications/Music.app' },
    { name: 'Xcode', icon: '🔨', path: '/Applications/Xcode.app' },
    { name: 'VS Code', icon: '🟦', path: '/Applications/Visual Studio Code.app' },
    { name: 'Slack', icon: '💬', path: '/Applications/Slack.app' },
    { name: 'Chrome', icon: '🌐', path: '/Applications/Google Chrome.app' },
  ];

  const q = query.toLowerCase();
  mockApps
    .filter((app) => app.name.toLowerCase().includes(q))
    .forEach((app) => {
      results.push({
        id: `app-${app.name}`,
        type: 'app',
        title: app.name,
        subtitle: app.path,
        icon: app.icon,
        iconType: 'emoji',
      });
    });

  return results.slice(0, 9);
}

export default function HotkeyWindow() {
  const { settings, searchQuery, setSearchQuery, setActiveWindow } = useAppStore();
  const [selectedIndex, setSelectedIndex] = useState(0);
  const [results, setResults] = useState<SearchResult[]>([]);
  const inputRef = useRef<HTMLInputElement>(null);

  useEffect(() => {
    inputRef.current?.focus();
  }, []);

  useEffect(() => {
    const r = getMockResults(searchQuery, settings.webSearch);
    setResults(r);
    setSelectedIndex(0);
  }, [searchQuery, settings.webSearch]);

  const handleKeyDown = useCallback(
    (e: React.KeyboardEvent) => {
      if (e.key === 'ArrowDown') {
        e.preventDefault();
        setSelectedIndex((i) => Math.min(i + 1, results.length - 1));
      } else if (e.key === 'ArrowUp') {
        e.preventDefault();
        setSelectedIndex((i) => Math.max(i - 1, 0));
      } else if (e.key === 'Escape') {
        setSearchQuery('');
        setResults([]);
      } else if ((e.metaKey || e.ctrlKey) && e.key === ',') {
        e.preventDefault();
        setActiveWindow('settings');
      } else if (e.key === 'Enter') {
        const selected = results[selectedIndex];
        if (selected?.type === 'calculator') {
          navigator.clipboard.writeText(selected.title).catch(() => {});
        }
      }
    },
    [results, selectedIndex, setSearchQuery, setActiveWindow]
  );

  const getResultIcon = (result: SearchResult) => {
    if (result.iconType === 'emoji') return <span className="result-icon">{result.icon}</span>;
    return <span className="result-icon result-icon-text">{result.type[0].toUpperCase()}</span>;
  };

  return (
    <div className="hotkey-window">
      <div className="search-bar">
        <Search size={18} className="search-icon" />
        <input
          ref={inputRef}
          type="text"
          value={searchQuery}
          onChange={(e) => setSearchQuery(e.target.value)}
          onKeyDown={handleKeyDown}
          placeholder="Search apps, files, web..."
          className="search-input"
          autoFocus
          autoComplete="off"
          spellCheck={false}
        />
        <span className="birdjump-badge">🐦</span>
      </div>

      {results.length > 0 && (
        <div className="results-list">
          {results.map((result, i) => (
            <div
              key={result.id}
              className={`result-item ${i === selectedIndex ? 'selected' : ''}`}
              onMouseEnter={() => setSelectedIndex(i)}
              onClick={() => {
                if (result.type === 'calculator') {
                  navigator.clipboard.writeText(result.title).catch(() => {});
                }
              }}
            >
              {getResultIcon(result)}
              <div className="result-text">
                <span className="result-title">{result.title}</span>
                {result.subtitle && <span className="result-subtitle">{result.subtitle}</span>}
              </div>
              <div className="result-actions">
                {i < 9 && <span className="shortcut-badge">⌘{i + 1}</span>}
                {i === selectedIndex && <ArrowRight size={12} className="enter-icon" />}
              </div>
            </div>
          ))}
        </div>
      )}
    </div>
  );
}
