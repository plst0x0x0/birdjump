import React, { useState, useRef } from 'react';
import type { HotkeyBinding } from '../types';

interface HotkeyInputProps {
  value: HotkeyBinding;
  onChange: (binding: HotkeyBinding) => void;
  className?: string;
}

const MAC_SYMBOLS: Record<string, string> = {
  Meta: '⌘',
  ctrl: '⌃',
  alt: '⌥',
  shift: '⇧',
  Backspace: '⌫',
  Delete: '⌦',
  Return: '↩',
  Enter: '↩',
  Tab: '⇥',
  Escape: '⎋',
  ArrowUp: '↑',
  ArrowDown: '↓',
  ArrowLeft: '←',
  ArrowRight: '→',
  Space: 'Space',
};

function bindingToDisplay(binding: HotkeyBinding): React.ReactNode[] {
  const parts: React.ReactNode[] = [];
  if (binding.ctrl) parts.push(<span key="ctrl" className="modifier-key">⌃</span>);
  if (binding.alt) parts.push(<span key="alt" className="modifier-key">⌥</span>);
  if (binding.shift) parts.push(<span key="shift" className="modifier-key">⇧</span>);
  if (binding.meta) parts.push(<span key="meta" className="modifier-key">⌘</span>);
  if (binding.key) {
    const display = MAC_SYMBOLS[binding.key] || binding.key.toUpperCase();
    parts.push(<span key="key" className="key-label">{display}</span>);
  }
  return parts;
}

export default function HotkeyInput({ value, onChange, className = '' }: HotkeyInputProps) {
  const [recording, setRecording] = useState(false);
  const ref = useRef<HTMLDivElement>(null);

  const handleKeyDown = (e: React.KeyboardEvent) => {
    e.preventDefault();
    e.stopPropagation();

    if (e.key === 'Escape') {
      setRecording(false);
      return;
    }

    const isModifier = ['Meta', 'Control', 'Alt', 'Shift'].includes(e.key);
    if (isModifier) return;

    const newBinding: HotkeyBinding = {
      ctrl: e.ctrlKey,
      alt: e.altKey,
      shift: e.shiftKey,
      meta: e.metaKey,
      key: e.key === ' ' ? 'Space' : e.key,
    };

    onChange(newBinding);
    setRecording(false);
  };

  return (
    <div
      ref={ref}
      tabIndex={0}
      className={`hotkey-input ${recording ? 'recording' : ''} ${className}`}
      onClick={() => { setRecording(true); ref.current?.focus(); }}
      onKeyDown={recording ? handleKeyDown : undefined}
      onBlur={() => setRecording(false)}
    >
      {recording ? (
        <span className="recording-text">Press shortcut...</span>
      ) : (
        <span className="hotkey-display">
          {bindingToDisplay(value).length > 0 ? bindingToDisplay(value) : <span className="placeholder">None</span>}
        </span>
      )}
    </div>
  );
}
