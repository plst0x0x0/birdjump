import { useState } from 'react';
import { Trash2 } from 'lucide-react';
import { useAppStore } from '../store';

export default function ClipboardViewer() {
  const { clipboardHistory, clearClipboardHistory } = useAppStore();
  const [query, setQuery] = useState('');
  const [selectedIndex, setSelectedIndex] = useState(0);

  const filtered = clipboardHistory.filter(
    (item) => !query || item.content.toLowerCase().includes(query.toLowerCase())
  );

  const displayItems = filtered.length > 0
    ? filtered
    : [
        {
          id: 'demo1',
          type: 'text' as const,
          content: 'Sample clipboard text — copy something to see it here',
          timestamp: Date.now(),
          wordCount: 9,
          charCount: 53,
        },
        {
          id: 'demo2',
          type: 'text' as const,
          content: 'https://github.com/your-username/birdjump',
          timestamp: Date.now() - 60000,
          wordCount: 1,
          charCount: 41,
        },
      ];

  const selected = displayItems[selectedIndex];

  return (
    <div className="clipboard-viewer">
      <div className="clipboard-search-bar">
        <input
          type="text"
          value={query}
          onChange={(e) => setQuery(e.target.value)}
          placeholder="Search clipboard history..."
          className="clipboard-search-input"
          autoFocus
        />
      </div>
      <div className="clipboard-layout">
        <div className="clipboard-list">
          {displayItems.map((item, i) => (
            <div
              key={item.id}
              className={`clipboard-item ${i === selectedIndex ? 'selected' : ''}`}
              onMouseEnter={() => setSelectedIndex(i)}
            >
              <span className="clipboard-item-icon">
                {item.type === 'text' ? '📄' : item.type === 'image' ? '🖼' : '📁'}
              </span>
              <div className="clipboard-item-text">
                <span className="clipboard-item-preview">
                  {item.content.slice(0, 60)}{item.content.length > 60 ? '...' : ''}
                </span>
              </div>
              {i < 9 && <span className="shortcut-badge">⌘{i + 1}</span>}
            </div>
          ))}
        </div>
        <div className="clipboard-preview">
          {selected ? (
            <>
              <div className="preview-content">{selected.content}</div>
              <div className="preview-meta">
                {selected.wordCount} words; {selected.charCount} chars
                <br />
                Copied {new Date(selected.timestamp).toLocaleString()}
              </div>
            </>
          ) : (
            <div className="preview-empty">Select an item to preview</div>
          )}
        </div>
      </div>
      <div className="clipboard-footer">
        <button className="btn btn-danger btn-sm" onClick={clearClipboardHistory}>
          <Trash2 size={12} /> Clear All History
        </button>
      </div>
    </div>
  );
}
