import { useState } from 'react';
import { Plus, Minus, Search } from 'lucide-react';
import { useAppStore } from '../../store';
import type { WebSearchEntry } from '../../types';

const WEB_ICONS: Record<string, string> = {
  google: 'G', lucky: 'G', images: '🖼', maps: '📍',
  translate: '🌐', gmail: 'M', drive: '▲', wiki: 'W',
  amazon: 'A', youtube: '▶', github: '⌥', bing: 'b',
  linkedin: 'in', stackoverflow: 'SO', imdb: 'IMDb',
  ebay: 'e', twitter: 'X', reddit: 'r/', npmjs: 'npm',
  wolfram: 'W', default: '🔍',
};

export default function WebSearchSettings() {
  const { settings, addWebSearch, updateWebSearch, removeWebSearch } = useAppStore();
  const [filterText, setFilterText] = useState('');
  const [showEnabledOnly, setShowEnabledOnly] = useState(false);
  const [activeTab, setActiveTab] = useState<'Search' | 'URLs / History'>('Search');
  const [editingId, setEditingId] = useState<string | null>(null);
  const [newEntry, setNewEntry] = useState<Partial<WebSearchEntry>>({});
  const [showAddForm, setShowAddForm] = useState(false);

  const filtered = settings.webSearch.filter((e) => {
    if (showEnabledOnly && !e.enabled) return false;
    if (filterText && !e.keyword.toLowerCase().includes(filterText.toLowerCase()) &&
      !e.displayText.toLowerCase().includes(filterText.toLowerCase())) return false;
    return true;
  });

  const handleAdd = () => {
    if (!newEntry.keyword || !newEntry.url) return;
    addWebSearch({
      id: Date.now().toString(),
      keyword: newEntry.keyword || '',
      displayText: newEntry.displayText || newEntry.keyword || '',
      url: newEntry.url || '',
      isCustom: true,
      enabled: true,
    });
    setNewEntry({});
    setShowAddForm(false);
  };

  return (
    <div className="settings-section">
      <div className="sub-tabs">
        <button className={`sub-tab ${activeTab === 'Search' ? 'active' : ''}`} onClick={() => setActiveTab('Search')}>Search</button>
        <button className={`sub-tab ${activeTab === 'URLs / History' ? 'active' : ''}`} onClick={() => setActiveTab('URLs / History')}>URLs / History</button>
      </div>

      {activeTab === 'Search' && (
        <>
          <div className="websearch-toolbar">
            <div className="search-filter">
              <Search size={14} />
              <input
                type="text"
                placeholder="Filter"
                value={filterText}
                onChange={(e) => setFilterText(e.target.value)}
                className="text-input filter-input"
              />
            </div>
            <label className="checkbox-label">
              <input
                type="checkbox"
                checked={showEnabledOnly}
                onChange={(e) => setShowEnabledOnly(e.target.checked)}
              />
              <span>Only show enabled searches</span>
            </label>
          </div>

          <div className="websearch-table">
            <div className="websearch-header">
              <span>Keyword</span>
              <span>Display text</span>
              <span>Custom</span>
              <span>Enabled</span>
            </div>
            {filtered.map((entry) => (
              <div key={entry.id} className={`websearch-row ${editingId === entry.id ? 'editing' : ''}`}>
                <div className="keyword-cell">
                  <span className="web-icon">{WEB_ICONS[entry.keyword] || WEB_ICONS.default}</span>
                  {editingId === entry.id ? (
                    <input
                      type="text"
                      value={entry.keyword}
                      onChange={(e) => updateWebSearch(entry.id, { keyword: e.target.value })}
                      className="text-input inline-edit"
                    />
                  ) : (
                    <span>{entry.keyword}</span>
                  )}
                </div>
                <div className="display-cell">
                  {entry.isCustom ? '✏️' : '🔒'}
                  {editingId === entry.id ? (
                    <input
                      type="text"
                      value={entry.displayText}
                      onChange={(e) => updateWebSearch(entry.id, { displayText: e.target.value })}
                      className="text-input inline-edit wide-edit"
                    />
                  ) : (
                    <span onClick={() => entry.isCustom && setEditingId(entry.id)}>{entry.displayText}</span>
                  )}
                </div>
                <div className="custom-cell">{entry.isCustom && '✓'}</div>
                <div className="enabled-cell">
                  <input
                    type="checkbox"
                    checked={entry.enabled}
                    onChange={(e) => updateWebSearch(entry.id, { enabled: e.target.checked })}
                  />
                </div>
                {entry.isCustom && (
                  <button className="icon-btn remove-btn" onClick={() => removeWebSearch(entry.id)}>
                    <Minus size={10} />
                  </button>
                )}
              </div>
            ))}
          </div>

          {showAddForm && (
            <div className="add-search-form">
              <input
                type="text"
                placeholder="Keyword"
                value={newEntry.keyword || ''}
                onChange={(e) => setNewEntry({ ...newEntry, keyword: e.target.value })}
                className="text-input"
              />
              <input
                type="text"
                placeholder="Display Text (use {query})"
                value={newEntry.displayText || ''}
                onChange={(e) => setNewEntry({ ...newEntry, displayText: e.target.value })}
                className="text-input"
              />
              <input
                type="text"
                placeholder="URL (use {query})"
                value={newEntry.url || ''}
                onChange={(e) => setNewEntry({ ...newEntry, url: e.target.value })}
                className="text-input"
              />
              <div className="settings-row-inline">
                <button className="btn btn-secondary" onClick={() => setShowAddForm(false)}>Cancel</button>
                <button className="btn btn-primary" onClick={handleAdd}>Add</button>
              </div>
            </div>
          )}

          <div className="websearch-footer">
            <button className="btn btn-secondary" onClick={() => setShowAddForm(true)}>
              <Plus size={12} /> Add Custom Search
            </button>
          </div>
        </>
      )}

      {activeTab === 'URLs / History' && (
        <div className="settings-group">
          <p className="settings-hint">URL history and bookmark search settings coming soon.</p>
        </div>
      )}
    </div>
  );
}
