import { useState } from 'react';
import { useAppStore } from '../../store';

const TABS = ['Search', 'Navigation', 'Buffer', 'Advanced'];

export default function FileSearchSettings() {
  const { settings, updateSettings } = useAppStore();
  const { fileSearch } = settings;
  const [activeTab, setActiveTab] = useState('Search');

  return (
    <div className="settings-section">
      <div className="sub-tabs">
        {TABS.map((tab) => (
          <button
            key={tab}
            className={`sub-tab ${activeTab === tab ? 'active' : ''}`}
            onClick={() => setActiveTab(tab)}
          >
            {tab}
          </button>
        ))}
      </div>

      {activeTab === 'Search' && (
        <div className="settings-group">
          <div className="settings-row">
            <div className="settings-label">Quick Search</div>
            <div className="settings-control">
              <label className="checkbox-label">
                <input
                  type="checkbox"
                  checked={fileSearch.quickSearchEnabled}
                  onChange={(e) => updateSettings('fileSearch.quickSearchEnabled', e.target.checked)}
                />
                <span>Enable Quick File Search mode</span>
              </label>
              <p className="settings-hint">Search for and open files quickly by prefixing your search term with <code>'</code> or <code>[spacebar]</code>. This is the best way to find files.</p>
            </div>
          </div>

          <div className="settings-row">
            <div className="settings-label">Opening Files</div>
            <div className="settings-control settings-row-inline">
              <label className="checkbox-label"><input type="checkbox" defaultChecked /></label>
              <input
                type="text"
                value={fileSearch.openKeyword}
                onChange={(e) => updateSettings('fileSearch.openKeyword', e.target.value)}
                className="text-input short-input"
              />
              <span className="settings-hint-inline">Use keyword followed by filename, e.g. <code>open notes.pdf</code></span>
            </div>
          </div>

          <div className="settings-row">
            <div className="settings-label">Revealing Files</div>
            <div className="settings-control settings-row-inline">
              <label className="checkbox-label"><input type="checkbox" defaultChecked /></label>
              <input
                type="text"
                value={fileSearch.findKeyword}
                onChange={(e) => updateSettings('fileSearch.findKeyword', e.target.value)}
                className="text-input short-input"
              />
              <span className="settings-hint-inline">Reveal the file in Finder/Explorer</span>
            </div>
          </div>

          <div className="settings-row">
            <div className="settings-label">Inside Files</div>
            <div className="settings-control settings-row-inline">
              <label className="checkbox-label"><input type="checkbox" defaultChecked /></label>
              <input
                type="text"
                value={fileSearch.insideKeyword}
                onChange={(e) => updateSettings('fileSearch.insideKeyword', e.target.value)}
                className="text-input short-input"
              />
              <span className="settings-hint-inline">Search file contents, e.g. <code>in rabbit from hat</code></span>
            </div>
          </div>

          <div className="settings-row">
            <div className="settings-label">File Tags</div>
            <div className="settings-control settings-row-inline">
              <label className="checkbox-label"><input type="checkbox" defaultChecked /></label>
              <input
                type="text"
                value={fileSearch.tagsKeyword}
                onChange={(e) => updateSettings('fileSearch.tagsKeyword', e.target.value)}
                className="text-input short-input"
              />
              <span className="settings-hint-inline">Search by tag, e.g. <code>tags magic tricks</code></span>
            </div>
          </div>

          <div className="settings-row">
            <div className="settings-label">Don't Show</div>
            <div className="settings-control">
              <div className="checkbox-grid">
                {(Object.entries(fileSearch.dontShow) as [string, boolean][]).map(([key, val]) => (
                  <label key={key} className="checkbox-label">
                    <input
                      type="checkbox"
                      checked={val}
                      onChange={(e) =>
                        updateSettings(`fileSearch.dontShow.${key}`, e.target.checked)
                      }
                    />
                    <span>
                      {key === 'plistFiles' ? 'Plist Files'
                        : key === 'sourceFiles' ? 'Source Files'
                        : key.charAt(0).toUpperCase() + key.slice(1)}
                    </span>
                  </label>
                ))}
              </div>
              <p className="settings-hint">Filter out file types when using open, reveal, and inside keywords. For complex filtering, use workflow scripts.</p>
            </div>
          </div>

          <div className="settings-row">
            <div className="settings-label">Result Limit</div>
            <div className="settings-control">
              <select
                value={fileSearch.resultLimit}
                onChange={(e) => updateSettings('fileSearch.resultLimit', Number(e.target.value))}
                className="select-input"
              >
                {[10, 15, 20, 30, 40, 50].map((n) => (
                  <option key={n} value={n}>{n}</option>
                ))}
              </select>
              <p className="settings-hint">Select more results for flexibility or fewer results for higher performance.</p>
            </div>
          </div>
        </div>
      )}

      {activeTab === 'Navigation' && (
        <div className="settings-group">
          <p className="settings-hint" style={{ marginTop: 8 }}>
            Start navigating the file system by typing <code>/</code> to go to the root folder, or <code>~</code> to go to your home folder.
          </p>
          <div className="settings-row">
            <div className="settings-label">Filtering</div>
            <div className="settings-control">
              <label className="checkbox-label">
                <input
                  type="checkbox"
                  checked={fileSearch.navigation.fuzzyMatching}
                  onChange={(e) =>
                    updateSettings('fileSearch.navigation.fuzzyMatching', e.target.checked)
                  }
                />
                <span>Fuzzy matching</span>
              </label>
              <p className="settings-hint">
                Fuzzy mode makes file system filtering match results more loosely. Includes non-anchored word-based matching and sequential capital letter matching (e.g. <code>gc</code> matches Google Chrome).
              </p>
            </div>
          </div>

          <div className="settings-row">
            <div className="settings-label">Shortcuts</div>
            <div className="settings-control">
              <label className="checkbox-label">
                <input
                  type="checkbox"
                  checked={fileSearch.navigation.arrowKeysForFolders}
                  onChange={(e) =>
                    updateSettings('fileSearch.navigation.arrowKeysForFolders', e.target.checked)
                  }
                />
                <span>Use ← and → for folder navigation</span>
              </label>
              <p className="settings-hint">By default, → shows the action panel and you can use ⌘↓ and ⌘↑ to navigate in and out of folders.</p>
              <label className="checkbox-label">
                <input
                  type="checkbox"
                  checked={fileSearch.navigation.enterOpensFolderInFinder}
                  onChange={(e) =>
                    updateSettings(
                      'fileSearch.navigation.enterOpensFolderInFinder',
                      e.target.checked
                    )
                  }
                />
                <span>Use ↩ to open folders in Finder</span>
              </label>
              <p className="settings-hint">By default, ↩ navigates into a folder. Use this option to open folders in Finder instead.</p>
            </div>
          </div>

          <div className="settings-row">
            <div className="settings-label">Previous Path</div>
            <div className="settings-control">
              <div className="keybinding-docs" style={{ display: 'inline-block' }}>
                <code>⌃⌥⇧⌘/</code>
              </div>
              <label className="checkbox-label" style={{ marginTop: 4 }}>
                <input type="checkbox" defaultChecked />
                <span>Keyword: <code>previous</code></span>
              </label>
              <p className="settings-hint">Use this hotkey or keyword to show the file browser for the last browsed path.</p>
            </div>
          </div>
        </div>
      )}

      {activeTab === 'Buffer' && (
        <div className="settings-group">
          <div className="settings-row">
            <div className="settings-control" style={{ gridColumn: '1 / -1' }}>
              <label className="checkbox-label checkbox-primary" style={{ fontSize: 14 }}>
                <input
                  type="checkbox"
                  checked={fileSearch.buffer.enabled}
                  onChange={(e) =>
                    updateSettings('fileSearch.buffer.enabled', e.target.checked)
                  }
                />
                <span>Enable temporary file buffer</span>
              </label>
              <p className="settings-hint" style={{ marginTop: 4 }}>
                The buffer is controlled using the <code>⌥</code> key in combination with the selected file in BirdJump's results.
              </p>
              <div className="keybinding-docs" style={{ marginTop: 8 }}>
                <code>⌥↑</code> <span>Add a file to the buffer, or remove it if already added.</span><br />
                <code>⌥↓</code> <span>Add a file and move to the next selection.</span><br />
                <code>⌥←</code> <span>Remove the last item from the buffer.</span><br />
                <code>⌥→</code> <span>Action all items in the buffer.</span>
              </div>
            </div>
          </div>

          <div className="settings-row">
            <div className="settings-label">Buffer Clearing</div>
            <div className="settings-control">
              <label className="checkbox-label">
                <input
                  type="checkbox"
                  checked={fileSearch.buffer.clearAfterAction}
                  onChange={(e) =>
                    updateSettings('fileSearch.buffer.clearAfterAction', e.target.checked)
                  }
                />
                <span>Clear after actioning items in the buffer</span>
              </label>
              <label className="checkbox-label">
                <input
                  type="checkbox"
                  checked={fileSearch.buffer.clearAfterTimeout}
                  onChange={(e) =>
                    updateSettings('fileSearch.buffer.clearAfterTimeout', e.target.checked)
                  }
                />
                <span>Clear if buffer isn't used for 5 minutes</span>
              </label>
              <p className="settings-hint">
                To remove all items from the buffer, use <code>⌥⌫</code>. Remove a single item by holding <code>⌥</code> and clicking it.
              </p>
            </div>
          </div>

          <div className="settings-row">
            <div className="settings-label">Compatibility</div>
            <div className="settings-control">
              <label className="checkbox-label">
                <input type="checkbox" />
                <span>Use ⇧⌥ as modifier key</span>
              </label>
              <p className="settings-hint">Use the same keys as above but with ⇧⌥ as the modifier instead of ⌥, which may better fit your default key bindings.</p>
            </div>
          </div>
        </div>
      )}

      {activeTab === 'Advanced' && (
        <div className="settings-group">
          <div className="settings-row">
            <div className="settings-label">Copy Path</div>
            <div className="settings-control">
              <label className="checkbox-label">
                <input
                  type="checkbox"
                  checked={fileSearch.advanced.escapePath}
                  onChange={(e) =>
                    updateSettings('fileSearch.advanced.escapePath', e.target.checked)
                  }
                />
                <span>Escape path on 'Copy path to Clipboard' action</span>
              </label>
              <p className="settings-hint">
                When using the copy action, escape the path for Terminal e.g. <code>/Users/you/Desktop/Andrew\'s Folder!/</code>
              </p>
            </div>
          </div>

          <div className="settings-row">
            <div className="settings-label">AppleScripts</div>
            <div className="settings-control">
              <label className="checkbox-label">
                <input
                  type="checkbox"
                  checked={fileSearch.advanced.runAppleScripts}
                  onChange={(e) =>
                    updateSettings('fileSearch.advanced.runAppleScripts', e.target.checked)
                  }
                />
                <span>Run AppleScripts instead of opening</span>
              </label>
              <p className="settings-hint">When dealing with AppleScripts, run them on pressing Return instead of opening. You can use <code>⌘O</code> to open selected AppleScripts at any point.</p>
            </div>
          </div>

          <div className="settings-row">
            <div className="settings-label">Performance</div>
            <div className="settings-control">
              <label className="checkbox-label">
                <input
                  type="checkbox"
                  checked={fileSearch.advanced.useFileTypeIconsForExternal}
                  onChange={(e) =>
                    updateSettings(
                      'fileSearch.advanced.useFileTypeIconsForExternal',
                      e.target.checked
                    )
                  }
                />
                <span>Use file type icons for files on external drives</span>
              </label>
              <p className="settings-hint">Instead of using the icons for the files themselves. This can prevent the need to spin up external drives unnecessarily.</p>
            </div>
          </div>

          <div className="settings-row">
            <div className="settings-label">Sorting</div>
            <div className="settings-control settings-row-inline">
              <label className="checkbox-label">
                <input
                  type="checkbox"
                  checked={fileSearch.advanced.touchFoldersAfterOpening}
                  onChange={(e) =>
                    updateSettings('fileSearch.advanced.touchFoldersAfterOpening', e.target.checked)
                  }
                />
                <span>Touch folders after opening them</span>
              </label>
              <label className="checkbox-label">
                <input
                  type="checkbox"
                  checked={fileSearch.advanced.touchAliasesAfterOpening}
                  onChange={(e) =>
                    updateSettings(
                      'fileSearch.advanced.touchAliasesAfterOpening',
                      e.target.checked
                    )
                  }
                />
                <span>Touch aliases after opening them</span>
              </label>
            </div>
            <p className="settings-hint" style={{ gridColumn: '2', marginTop: -4 }}>Update the <code>kMDItemFSContentChangeDate</code> flag to current timestamp to prioritise folders/aliases in search results.</p>
          </div>

          <div className="settings-row">
            <div className="settings-label">Home Folder</div>
            <div className="settings-control">
              <select className="select-input" defaultValue="~">
                <option value="~">~ (Unix standard)</option>
                <option value="home">home</option>
                <option value="custom">Custom…</option>
              </select>
              <label className="checkbox-label" style={{ marginTop: 4 }}>
                <input type="checkbox" />
                <span>Use custom home folder location</span>
              </label>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}
