import { useState } from 'react';
import { Plus, Minus } from 'lucide-react';
import { useAppStore } from '../../store';

export default function DefaultResultsSettings() {
  const { settings, updateSettings, addCustomFolder, removeCustomFolder } = useAppStore();
  const { defaultResults } = settings;
  const [newFormat, setNewFormat] = useState('');
  const [newFolder, setNewFolder] = useState('');

  return (
    <div className="settings-section">

      <div className="settings-group">
        <div className="settings-row">
          <div className="settings-label">App Matching</div>
          <div className="settings-control">
            <div className="radio-group">
              <label className="radio-label">
                <input
                  type="radio"
                  name="appMatching"
                  value="fuzzy_capital"
                  checked={defaultResults.appMatching === 'fuzzy_capital'}
                  onChange={() => updateSettings('defaultResults.appMatching', 'fuzzy_capital')}
                />
                <span>Fuzzy capital letters (e.g. <code>gc</code> → Google Chrome)</span>
              </label>
              <label className="radio-label">
                <input
                  type="radio"
                  name="appMatching"
                  value="full_fuzzy"
                  checked={defaultResults.appMatching === 'full_fuzzy'}
                  onChange={() => updateSettings('defaultResults.appMatching', 'full_fuzzy')}
                />
                <span>Full fuzzy match from word boundary</span>
              </label>
            </div>
          </div>
        </div>

        <div className="settings-row">
          <div className="settings-label">Extensions</div>
          <div className="settings-control">
            <label className="checkbox-label">
              <input
                type="checkbox"
                checked={defaultResults.extensionsContacts}
                onChange={(e) => updateSettings('defaultResults.extensionsContacts', e.target.checked)}
              />
              <span>Contacts</span>
            </label>
          </div>
        </div>

        <div className="settings-row">
          <div className="settings-label">Extras</div>
          <div className="settings-control">
            <div className="checkbox-grid">
              {[
                ['folders', 'Folders'],
                ['documents', 'Documents'],
                ['textFiles', 'Text Files'],
                ['images', 'Images'],
                ['archives', 'Archives'],
                ['applescript', 'AppleScript'],
              ].map(([key, label]) => (
                <label key={key} className="checkbox-label">
                  <input
                    type="checkbox"
                    checked={defaultResults.extrasEnabled[key as keyof typeof defaultResults.extrasEnabled] as boolean}
                    onChange={(e) =>
                      updateSettings(`defaultResults.extrasEnabled.${key}`, e.target.checked)
                    }
                  />
                  <span>{label}</span>
                </label>
              ))}
            </div>
            <div className="custom-formats-row">
              <span className="settings-sublabel">Custom formats:</span>
              <div className="tag-list">
                {defaultResults.extrasEnabled.customFormats.map((fmt) => (
                  <span key={fmt} className="tag">
                    {fmt}
                    <button
                      onClick={() =>
                        updateSettings(
                          'defaultResults.extrasEnabled.customFormats',
                          defaultResults.extrasEnabled.customFormats.filter((f) => f !== fmt)
                        )
                      }
                    >
                      ×
                    </button>
                  </span>
                ))}
                <input
                  type="text"
                  placeholder=".ext"
                  value={newFormat}
                  onChange={(e) => setNewFormat(e.target.value)}
                  onKeyDown={(e) => {
                    if (e.key === 'Enter' && newFormat.trim()) {
                      updateSettings('defaultResults.extrasEnabled.customFormats', [
                        ...defaultResults.extrasEnabled.customFormats,
                        newFormat.trim(),
                      ]);
                      setNewFormat('');
                    }
                  }}
                  className="inline-input"
                />
              </div>
            </div>
          </div>
        </div>

        <div className="settings-row">
          <div className="settings-label">Search Scope</div>
          <div className="settings-control">
            <label className="checkbox-label">
              <input
                type="checkbox"
                checked={defaultResults.searchScope.macosApplicationFolder}
                onChange={(e) =>
                  updateSettings('defaultResults.searchScope.macosApplicationFolder', e.target.checked)
                }
              />
              <span>macOS Applications folder</span>
            </label>
            <label className="checkbox-label">
              <input
                type="checkbox"
                checked={defaultResults.searchScope.foldersInHome}
                onChange={(e) =>
                  updateSettings('defaultResults.searchScope.foldersInHome', e.target.checked)
                }
              />
              <span>Folders in Home</span>
            </label>

            <div className="folder-list">
              {defaultResults.searchScope.customFolders.map((folder) => (
                <div key={folder} className="folder-item">
                  <span className="folder-path">{folder}</span>
                  <button
                    className="icon-btn remove-btn"
                    onClick={() => removeCustomFolder(folder)}
                  >
                    <Minus size={12} />
                  </button>
                </div>
              ))}
              <div className="folder-add-row">
                <input
                  type="text"
                  placeholder="/path/to/folder"
                  value={newFolder}
                  onChange={(e) => setNewFolder(e.target.value)}
                  className="text-input"
                />
                <button
                  className="icon-btn add-btn"
                  onClick={() => {
                    if (newFolder.trim()) {
                      addCustomFolder(newFolder.trim());
                      setNewFolder('');
                    }
                  }}
                >
                  <Plus size={12} />
                </button>
                <button
                  className="icon-btn remove-btn"
                  onClick={() => {
                    if (defaultResults.searchScope.customFolders.length > 0) {
                      removeCustomFolder(
                        defaultResults.searchScope.customFolders[
                          defaultResults.searchScope.customFolders.length - 1
                        ]
                      );
                    }
                  }}
                >
                  <Minus size={12} />
                </button>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}
