import { useAppStore } from '../../store';
import HotkeyInput from '../HotkeyInput';
import type { ClipboardRetentionPeriod } from '../../types';

const DURATIONS: { value: ClipboardRetentionPeriod; label: string }[] = [
  { value: '24h', label: '24 Hours' },
  { value: '3d', label: '3 Days' },
  { value: '7d', label: '7 Days' },
  { value: '1m', label: '1 Month' },
  { value: '3m', label: '3 Months' },
];

export default function ClipboardHistorySettings() {
  const { settings, updateSettings, clearClipboardHistory } = useAppStore();
  const { clipboardHistory } = settings;

  return (
    <div className="settings-section">
      <div className="settings-group">
        <div className="settings-row">
          <div className="settings-label">Clipboard History</div>
          <div className="settings-control">
            <div className="clipboard-duration-grid">
              <div className="duration-item">
                <label className="checkbox-label">
                  <input
                    type="checkbox"
                    checked={clipboardHistory.keepPlainText}
                    onChange={(e) =>
                      updateSettings('clipboardHistory.keepPlainText', e.target.checked)
                    }
                  />
                  <span>Keep Plain Text</span>
                </label>
                <select
                  value={clipboardHistory.keepPlainTextDuration}
                  onChange={(e) =>
                    updateSettings('clipboardHistory.keepPlainTextDuration', e.target.value)
                  }
                  className="select-input"
                  disabled={!clipboardHistory.keepPlainText}
                >
                  {DURATIONS.map((d) => <option key={d.value} value={d.value}>{d.label}</option>)}
                </select>
              </div>
              <div className="duration-item">
                <label className="checkbox-label">
                  <input
                    type="checkbox"
                    checked={clipboardHistory.keepImages}
                    onChange={(e) =>
                      updateSettings('clipboardHistory.keepImages', e.target.checked)
                    }
                  />
                  <span>Keep Images</span>
                </label>
                <select
                  value={clipboardHistory.keepImagesDuration}
                  onChange={(e) =>
                    updateSettings('clipboardHistory.keepImagesDuration', e.target.value)
                  }
                  className="select-input"
                  disabled={!clipboardHistory.keepImages}
                >
                  {DURATIONS.map((d) => <option key={d.value} value={d.value}>{d.label}</option>)}
                </select>
              </div>
              <div className="duration-item">
                <label className="checkbox-label">
                  <input
                    type="checkbox"
                    checked={clipboardHistory.keepFileLists}
                    onChange={(e) =>
                      updateSettings('clipboardHistory.keepFileLists', e.target.checked)
                    }
                  />
                  <span>Keep File Lists</span>
                </label>
                <select
                  value={clipboardHistory.keepFileListsDuration}
                  onChange={(e) =>
                    updateSettings('clipboardHistory.keepFileListsDuration', e.target.value)
                  }
                  className="select-input"
                  disabled={!clipboardHistory.keepFileLists}
                >
                  {DURATIONS.map((d) => <option key={d.value} value={d.value}>{d.label}</option>)}
                </select>
              </div>
            </div>
          </div>
        </div>

        <div className="settings-row">
          <div className="settings-label">Viewer Hotkey</div>
          <div className="settings-control">
            <HotkeyInput
              value={clipboardHistory.viewerHotkey}
              onChange={(v) => updateSettings('clipboardHistory.viewerHotkey', v)}
            />
            <p className="settings-hint">Hotkey to open the clipboard history viewer.</p>
          </div>
        </div>

        <div className="settings-row">
          <div className="settings-label">Viewer Keyword</div>
          <div className="settings-control settings-row-inline">
            <label className="checkbox-label">
              <input
                type="checkbox"
                checked={clipboardHistory.viewerKeywordEnabled}
                onChange={(e) =>
                  updateSettings('clipboardHistory.viewerKeywordEnabled', e.target.checked)
                }
              />
            </label>
            <input
              type="text"
              value={clipboardHistory.viewerKeyword}
              onChange={(e) => updateSettings('clipboardHistory.viewerKeyword', e.target.value)}
              className="text-input"
            />
            <p className="settings-hint">Type this keyword in the search bar to open clipboard history.</p>
          </div>
        </div>

        <div className="settings-row">
          <div className="settings-label">Clear History</div>
          <div className="settings-control">
            <button className="btn btn-danger" onClick={clearClipboardHistory}>
              Clear All History Now
            </button>
          </div>
        </div>

        <div className="settings-row">
          <div className="settings-label">Snippets</div>
          <div className="settings-control">
            <label className="checkbox-label">
              <input
                type="checkbox"
                checked={clipboardHistory.showAllSnippetsAtTop}
                onChange={(e) =>
                  updateSettings('clipboardHistory.showAllSnippetsAtTop', e.target.checked)
                }
              />
              <span>Show "All Snippets" at top of Clipboard History</span>
            </label>
            <label className="checkbox-label">
              <input
                type="checkbox"
                checked={clipboardHistory.showSnippetsWhenSearching}
                onChange={(e) =>
                  updateSettings('clipboardHistory.showSnippetsWhenSearching', e.target.checked)
                }
              />
              <span>Show Snippets when searching Clipboard History</span>
            </label>
          </div>
        </div>
      </div>
    </div>
  );
}
