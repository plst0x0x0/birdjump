import {
  Settings, Search, Clipboard, Type, Globe, Calculator, Brain,
  Layout, File, ChevronRight,
} from 'lucide-react';
import { useAppStore } from '../../store';
import GeneralSettings from './GeneralSettings';
import DefaultResultsSettings from './DefaultResultsSettings';
import FileSearchSettings from './FileSearchSettings';
import ClipboardHistorySettings from './ClipboardHistorySettings';
import SnippetsSettings from './SnippetsSettings';
import WebSearchSettings from './WebSearchSettings';
import CalculatorSettings from './CalculatorSettings';
import AISettings from './AISettings';

const MAIN_TABS = [
  { id: 'General', icon: <Settings size={16} />, label: 'General' },
  { id: 'Features', icon: <Layout size={16} />, label: 'Features' },
  { id: 'AI', icon: <Brain size={16} />, label: 'AI' },
];

const FEATURES_TABS = [
  { id: 'Default Results', icon: <Search size={14} />, label: 'Default Results', sub: 'Scope, Types, Fallbacks' },
  { id: 'File Search', icon: <File size={14} />, label: 'File Search', sub: 'Search, Navigation, Buffer' },
  { id: 'Clipboard History', icon: <Clipboard size={14} />, label: 'Clipboard History', sub: 'History, Merging' },
  { id: 'Snippets', icon: <Type size={14} />, label: 'Snippets', sub: 'Snippets, Clippings' },
  { id: 'Web Search', icon: <Globe size={14} />, label: 'Web Search', sub: 'Custom, URLs, History' },
  { id: 'Calculator', icon: <Calculator size={14} />, label: 'Calculator', sub: 'Standard, Advanced' },
];

export default function SettingsWindow() {
  const { settingsTab, setSettingsTab, settingsFeaturesTab, setSettingsFeaturesTab } = useAppStore();

  const renderFeaturesContent = () => {
    switch (settingsFeaturesTab) {
      case 'Default Results': return <DefaultResultsSettings />;
      case 'File Search': return <FileSearchSettings />;
      case 'Clipboard History': return <ClipboardHistorySettings />;
      case 'Snippets': return <SnippetsSettings />;
      case 'Web Search': return <WebSearchSettings />;
      case 'Calculator': return <CalculatorSettings />;
      default: return <DefaultResultsSettings />;
    }
  };

  const renderContent = () => {
    switch (settingsTab) {
      case 'General': return <GeneralSettings />;
      case 'Features': return (
        <div className="features-layout">
          <div className="features-sidebar">
            {FEATURES_TABS.map((tab) => (
              <button
                key={tab.id}
                className={`features-nav-item ${settingsFeaturesTab === tab.id ? 'active' : ''}`}
                onClick={() => setSettingsFeaturesTab(tab.id)}
              >
                <span className="feature-nav-icon">{tab.icon}</span>
                <div className="feature-nav-text">
                  <span className="feature-nav-label">{tab.label}</span>
                  <span className="feature-nav-sub">{tab.sub}</span>
                </div>
                <ChevronRight size={12} className="feature-nav-arrow" />
              </button>
            ))}
          </div>
          <div className="features-content">
            <div className="features-content-header">
              <div className="features-content-icon">
                {FEATURES_TABS.find((t) => t.id === settingsFeaturesTab)?.icon}
              </div>
              <div>
                <h2>{settingsFeaturesTab}</h2>
              </div>
            </div>
            {renderFeaturesContent()}
          </div>
        </div>
      );
      case 'AI': return <AISettings />;
      default: return <GeneralSettings />;
    }
  };

  return (
    <div className="settings-window">
      <div className="settings-titlebar">
        <div className="titlebar-dots">
          <span className="dot red" />
          <span className="dot yellow" />
          <span className="dot green" />
        </div>
        <div className="titlebar-tabs">
          {MAIN_TABS.map((tab) => (
            <button
              key={tab.id}
              className={`titlebar-tab ${settingsTab === tab.id ? 'active' : ''}`}
              onClick={() => setSettingsTab(tab.id)}
            >
              {tab.icon}
              <span>{tab.label}</span>
            </button>
          ))}
        </div>
        <div className="titlebar-search">
          <Search size={12} />
          <input type="text" placeholder="Search Preferences" className="titlebar-search-input" />
        </div>
      </div>

      <div className="settings-body">
        {renderContent()}
      </div>
    </div>
  );
}
