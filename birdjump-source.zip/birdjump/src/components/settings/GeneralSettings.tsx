import { useAppStore } from '../../store';
import HotkeyInput from '../HotkeyInput';

export default function GeneralSettings() {
  const { settings, updateSettings } = useAppStore();
  const { general } = settings;

  return (
    <div className="settings-section">
      <div className="settings-group">
        <div className="settings-row">
          <div className="settings-label">Startup</div>
          <div className="settings-control">
            <label className="checkbox-label">
              <input
                type="checkbox"
                checked={general.launchAtLogin}
                onChange={(e) => updateSettings('general.launchAtLogin', e.target.checked)}
              />
              <span>Launch BirdJump at login</span>
            </label>
            <button className="btn btn-danger" onClick={() => {/* quit app */}}>
              Quit App
            </button>
          </div>
        </div>

        <div className="settings-row">
          <div className="settings-label">App Hotkey</div>
          <div className="settings-control">
            <HotkeyInput
              value={general.appHotkey}
              onChange={(v) => updateSettings('general.appHotkey', v)}
            />
            <p className="settings-hint">Click the field and press your desired key combination to set the hotkey for opening BirdJump.</p>
          </div>
        </div>

        <div className="settings-row">
          <div className="settings-label">Permissions</div>
          <div className="settings-control permissions-grid">
            <button className="btn btn-secondary" onClick={() => {/* open accessibility prefs */}}>
              Open Accessibility Preferences
            </button>
            <button className="btn btn-secondary" onClick={() => {/* open full disk prefs */}}>
              Open macOS Full Disk Access Preferences
            </button>
            <button className="btn btn-secondary" onClick={() => {/* open automation prefs */}}>
              Open macOS Automation Preferences
            </button>
            <button className="btn btn-secondary" onClick={() => {/* open contacts prefs */}}>
              Open macOS Contact Preferences
            </button>
          </div>
        </div>
      </div>
    </div>
  );
}
