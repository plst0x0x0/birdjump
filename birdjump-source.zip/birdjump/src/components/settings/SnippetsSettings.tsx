import { useState } from 'react';
import { Plus, Minus, Edit2, Download, Upload } from 'lucide-react';
import { useAppStore } from '../../store';
import HotkeyInput from '../HotkeyInput';
import type { Snippet, SnippetCollection } from '../../types';

interface SnippetModalProps {
  collectionId: string;
  snippet?: Snippet;
  onClose: () => void;
  onSave: (s: Snippet) => void;
}

function SnippetModal({ collectionId, snippet, onClose, onSave }: SnippetModalProps) {
  const [name, setName] = useState(snippet?.name || '');
  const [keyword, setKeyword] = useState(snippet?.keyword || '');
  const [content, setContent] = useState(snippet?.content || '');

  return (
    <div className="modal-overlay" onClick={onClose}>
      <div className="modal" onClick={(e) => e.stopPropagation()}>
        <h3>{snippet ? 'Edit Snippet' : 'New Snippet'}</h3>
        <div className="modal-field">
          <label>Name</label>
          <input type="text" value={name} onChange={(e) => setName(e.target.value)} className="text-input" />
        </div>
        <div className="modal-field">
          <label>Keyword</label>
          <input type="text" value={keyword} onChange={(e) => setKeyword(e.target.value)} className="text-input" />
        </div>
        <div className="modal-field">
          <label>Snippet</label>
          <textarea value={content} onChange={(e) => setContent(e.target.value)} className="textarea-input" rows={4} />
        </div>
        <div className="modal-actions">
          <button className="btn btn-secondary" onClick={onClose}>Cancel</button>
          <button
            className="btn btn-primary"
            onClick={() =>
              onSave({
                id: snippet?.id || Date.now().toString(),
                name, keyword, content, collectionId,
              })
            }
          >
            Save
          </button>
        </div>
      </div>
    </div>
  );
}

interface CollectionModalProps {
  collection?: SnippetCollection;
  onClose: () => void;
  onSave: (c: SnippetCollection) => void;
}

function CollectionModal({ collection, onClose, onSave }: CollectionModalProps) {
  const [name, setName] = useState(collection?.name || '');
  const [affix, setAffix] = useState(collection?.affix || '!');
  const [keyword, setKeyword] = useState(collection?.keyword || '');

  return (
    <div className="modal-overlay" onClick={onClose}>
      <div className="modal" onClick={(e) => e.stopPropagation()}>
        <h3>{collection ? 'Edit Collection' : 'New Collection'}</h3>
        <div className="modal-field">
          <label>Name</label>
          <input type="text" value={name} onChange={(e) => setName(e.target.value)} className="text-input" />
        </div>
        <div className="modal-field">
          <label>Affix</label>
          <input type="text" value={affix} onChange={(e) => setAffix(e.target.value)} className="text-input" />
        </div>
        <div className="modal-field">
          <label>Keyword</label>
          <input type="text" value={keyword} onChange={(e) => setKeyword(e.target.value)} className="text-input" />
        </div>
        <div className="modal-actions">
          <button className="btn btn-secondary" onClick={onClose}>Cancel</button>
          <button
            className="btn btn-primary"
            onClick={() =>
              onSave({
                id: collection?.id || Date.now().toString(),
                name, affix, keyword,
                snippets: collection?.snippets || [],
              })
            }
          >
            Save
          </button>
        </div>
      </div>
    </div>
  );
}

export default function SnippetsSettings() {
  const { settings, updateSettings, addSnippetCollection, updateSnippetCollection, removeSnippetCollection } =
    useAppStore();
  const { snippets } = settings;

  const [selectedCollectionId, setSelectedCollectionId] = useState<string>(
    snippets.collections[0]?.id || ''
  );
  const [showCollectionModal, setShowCollectionModal] = useState(false);
  const [editingCollection, setEditingCollection] = useState<SnippetCollection | undefined>();
  const [showSnippetModal, setShowSnippetModal] = useState(false);
  const [editingSnippet, setEditingSnippet] = useState<Snippet | undefined>();

  const selectedCollection = snippets.collections.find((c) => c.id === selectedCollectionId);

  const handleSaveCollection = (col: SnippetCollection) => {
    if (editingCollection) {
      updateSnippetCollection(col.id, col);
    } else {
      addSnippetCollection(col);
      setSelectedCollectionId(col.id);
    }
    setShowCollectionModal(false);
    setEditingCollection(undefined);
  };

  const handleSaveSnippet = (snippet: Snippet) => {
    if (!selectedCollection) return;
    const updatedSnippets = editingSnippet
      ? selectedCollection.snippets.map((s) => (s.id === snippet.id ? snippet : s))
      : [...selectedCollection.snippets, snippet];
    updateSnippetCollection(selectedCollectionId, { snippets: updatedSnippets });
    setShowSnippetModal(false);
    setEditingSnippet(undefined);
  };

  const handleRemoveSnippet = (id: string) => {
    if (!selectedCollection) return;
    updateSnippetCollection(selectedCollectionId, {
      snippets: selectedCollection.snippets.filter((s) => s.id !== id),
    });
  };

  const handleExport = () => {
    const data = JSON.stringify(snippets.collections, null, 2);
    const blob = new Blob([data], { type: 'application/json' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = 'birdjump-snippets.json';
    a.click();
  };

  return (
    <div className="settings-section">
      {showCollectionModal && (
        <CollectionModal
          collection={editingCollection}
          onClose={() => { setShowCollectionModal(false); setEditingCollection(undefined); }}
          onSave={handleSaveCollection}
        />
      )}
      {showSnippetModal && selectedCollection && (
        <SnippetModal
          collectionId={selectedCollectionId}
          snippet={editingSnippet}
          onClose={() => { setShowSnippetModal(false); setEditingSnippet(undefined); }}
          onSave={handleSaveSnippet}
        />
      )}

      <div className="settings-group">
        <div className="settings-row">
          <div className="settings-label">Viewer Hotkey</div>
          <div className="settings-control">
            <HotkeyInput
              value={snippets.viewerHotkey}
              onChange={(v) => updateSettings('snippets.viewerHotkey', v)}
            />
          </div>
        </div>
        <div className="settings-row">
          <div className="settings-label">Snippet Keyword</div>
          <div className="settings-control settings-row-inline">
            <label className="checkbox-label">
              <input
                type="checkbox"
                checked={snippets.snippetKeywordEnabled}
                onChange={(e) => updateSettings('snippets.snippetKeywordEnabled', e.target.checked)}
              />
            </label>
            <input
              type="text"
              value={snippets.snippetKeyword}
              onChange={(e) => updateSettings('snippets.snippetKeyword', e.target.value)}
              className="text-input short-input"
            />
            <label className="checkbox-label">
              <input
                type="checkbox"
                checked={snippets.showKeywordInResult}
                onChange={(e) => updateSettings('snippets.showKeywordInResult', e.target.checked)}
              />
              <span>Show keyword in result</span>
            </label>
          </div>
        </div>
        <div className="settings-row">
          <div className="settings-label">Matching</div>
          <div className="settings-control">
            <select
              value={snippets.matchingMode}
              onChange={(e) => updateSettings('snippets.matchingMode', e.target.value)}
              className="select-input"
            >
              <option value="name_keyword_snippet">Name, keyword or snippet</option>
              <option value="name_keyword">Name, keyword</option>
            </select>
          </div>
        </div>
      </div>

      <div className="snippets-container">
        <div className="collections-panel">
          <div className="panel-header">
            <span>Collections</span>
            <div className="panel-actions">
              <button className="icon-btn" onClick={() => { setEditingCollection(undefined); setShowCollectionModal(true); }}>
                <Plus size={12} />
              </button>
              <button
                className="icon-btn"
                onClick={() => { if (selectedCollection) removeSnippetCollection(selectedCollectionId); }}
              >
                <Minus size={12} />
              </button>
            </div>
          </div>
          {snippets.collections.map((col) => (
            <div
              key={col.id}
              className={`collection-item ${col.id === selectedCollectionId ? 'active' : ''}`}
              onClick={() => setSelectedCollectionId(col.id)}
            >
              <span>{col.name}</span>
              <button
                className="icon-btn edit-btn"
                onClick={(e) => {
                  e.stopPropagation();
                  setEditingCollection(col);
                  setShowCollectionModal(true);
                }}
              >
                <Edit2 size={10} />
              </button>
            </div>
          ))}
        </div>

        <div className="snippets-panel">
          <div className="panel-header">
            <span>Snippets — {selectedCollection?.name}</span>
            <div className="panel-actions">
              <button className="icon-btn" onClick={() => { setEditingSnippet(undefined); setShowSnippetModal(true); }}>
                <Plus size={12} />
              </button>
              <button className="icon-btn" onClick={() => {/* remove selected */}}>
                <Minus size={12} />
              </button>
            </div>
          </div>
          <div className="snippets-table-header">
            <span>Name</span>
            <span>Keyword</span>
            <span>Snippet</span>
          </div>
          {selectedCollection?.snippets.map((s) => (
            <div key={s.id} className="snippet-row">
              <span>{s.name}</span>
              <span className="snippet-keyword">{s.keyword}</span>
              <span className="snippet-content">{s.content.slice(0, 50)}</span>
              <div className="snippet-row-actions">
                <button className="icon-btn" onClick={() => { setEditingSnippet(s); setShowSnippetModal(true); }}>
                  <Edit2 size={10} />
                </button>
                <button className="icon-btn remove-btn" onClick={() => handleRemoveSnippet(s.id)}>
                  <Minus size={10} />
                </button>
              </div>
            </div>
          ))}
        </div>
      </div>

      <div className="settings-row" style={{ marginTop: 16 }}>
        <div className="settings-control settings-row-inline">
          <button className="btn btn-secondary" onClick={handleExport}>
            <Download size={14} /> Export Snippets
          </button>
          <button className="btn btn-secondary">
            <Upload size={14} /> Import Snippets
          </button>
        </div>
      </div>
    </div>
  );
}
