import { useAppStore } from '../../store';

export default function AISettings() {
  const { settings, updateSettings } = useAppStore();
  const { ai } = settings;

  return (
    <div className="settings-section">
      <div className="settings-group">
        <div className="settings-row">
          <div className="settings-label">AI Provider</div>
          <div className="settings-control">
            <select
              value={ai.provider}
              onChange={(e) => updateSettings('ai.provider', e.target.value)}
              className="select-input"
            >
              <option value="none">None (Disabled)</option>
              <option value="openai">OpenAI</option>
              <option value="anthropic">Anthropic (Claude)</option>
            </select>
          </div>
        </div>

        {ai.provider !== 'none' && (
          <>
            <div className="settings-row">
              <div className="settings-label">API Key</div>
              <div className="settings-control">
                <input
                  type="password"
                  value={ai.apiKey}
                  onChange={(e) => updateSettings('ai.apiKey', e.target.value)}
                  placeholder="sk-..."
                  className="text-input"
                />
                <p className="settings-hint">Your API key is stored locally and never shared.</p>
              </div>
            </div>

            <div className="settings-row">
              <div className="settings-label">Model</div>
              <div className="settings-control">
                {ai.provider === 'openai' ? (
                  <select
                    value={ai.model}
                    onChange={(e) => updateSettings('ai.model', e.target.value)}
                    className="select-input"
                  >
                    <option value="gpt-4o">GPT-4o</option>
                    <option value="gpt-4o-mini">GPT-4o Mini</option>
                    <option value="gpt-4-turbo">GPT-4 Turbo</option>
                    <option value="gpt-3.5-turbo">GPT-3.5 Turbo</option>
                  </select>
                ) : (
                  <select
                    value={ai.model}
                    onChange={(e) => updateSettings('ai.model', e.target.value)}
                    className="select-input"
                  >
                    <option value="claude-opus-4-5">Claude Opus 4.5</option>
                    <option value="claude-sonnet-4-5">Claude Sonnet 4.5</option>
                    <option value="claude-haiku-4-5">Claude Haiku 4.5</option>
                  </select>
                )}
              </div>
            </div>

            <div className="settings-row">
              <div className="settings-label">Usage</div>
              <div className="settings-control">
                <p className="settings-hint">
                  When AI is enabled, you can prefix your query with <code>ai</code> or <code>?</code> in the search bar to ask questions directly. 
                  Results appear inline in BirdJump.
                </p>
              </div>
            </div>
          </>
        )}
      </div>
    </div>
  );
}
