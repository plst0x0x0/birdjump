export default function CalculatorSettings() {
  return (
    <div className="settings-section">
      <div className="settings-group">
        <div className="settings-row">
          <div className="settings-label">Calculator</div>
          <div className="settings-control">
            <p className="settings-hint">
              BirdJump includes a built-in calculator. Just type a math expression in the search bar 
              (e.g. <code>42 * 3.14</code>) and the result appears instantly as a result item. 
              Press Enter to copy the result to the clipboard.
            </p>
          </div>
        </div>
        <div className="settings-row">
          <div className="settings-label">Supported Operations</div>
          <div className="settings-control">
            <div className="keybinding-docs">
              <code>+, -, *, /</code> <span>Basic arithmetic</span><br />
              <code>^</code> <span>Exponentiation (2^8 = 256)</span><br />
              <code>sqrt(x)</code> <span>Square root</span><br />
              <code>sin, cos, tan</code> <span>Trigonometry</span><br />
              <code>log(x), ln(x)</code> <span>Logarithms</span><br />
              <code>pi, e</code> <span>Mathematical constants</span><br />
              <code>hex(n), bin(n)</code> <span>Number base conversion</span>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}
