/**
 * Safe wrapper around Tauri's invoke — falls back gracefully in browser/dev mode.
 */
async function tauriInvoke<T>(command: string, args?: Record<string, unknown>): Promise<T | null> {
  try {
    // Tauri injects __TAURI__ at runtime in the desktop app
    if (typeof window !== 'undefined' && '__TAURI__' in window) {
      const { invoke } = await import('@tauri-apps/api/core');
      return await invoke<T>(command, args);
    }
  } catch (e) {
    console.warn(`[BirdJump] Tauri command '${command}' failed:`, e);
  }
  return null;
}

export const TauriAPI = {
  showMainWindow: () => tauriInvoke<void>('show_main_window'),
  hideMainWindow: () => tauriInvoke<void>('hide_main_window'),
  showSettings: () => tauriInvoke<void>('show_settings_window'),
  openUrl: (url: string) => tauriInvoke<void>('open_url', { url }),
  quitApp: () => tauriInvoke<void>('quit_app'),
  getClipboardText: () => tauriInvoke<string>('get_clipboard_text'),
};
