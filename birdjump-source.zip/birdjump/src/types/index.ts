export interface HotkeyBinding {
  ctrl: boolean;
  alt: boolean;
  shift: boolean;
  meta: boolean; // Cmd on Mac
  key: string;
}

export type ClipboardRetentionPeriod = '24h' | '3d' | '7d' | '1m' | '3m';

export interface ClipboardHistorySettings {
  keepPlainText: boolean;
  keepPlainTextDuration: ClipboardRetentionPeriod;
  keepImages: boolean;
  keepImagesDuration: ClipboardRetentionPeriod;
  keepFileLists: boolean;
  keepFileListsDuration: ClipboardRetentionPeriod;
  viewerHotkey: HotkeyBinding;
  viewerKeyword: string;
  viewerKeywordEnabled: boolean;
  showAllSnippetsAtTop: boolean;
  showSnippetsWhenSearching: boolean;
}

export interface SnippetCollection {
  id: string;
  name: string;
  affix: string;
  keyword: string;
  snippets: Snippet[];
}

export interface Snippet {
  id: string;
  name: string;
  keyword: string;
  content: string;
  collectionId: string;
}

export type SnippetMatchingMode = 'name_keyword_snippet' | 'name_keyword';

export interface SnippetsSettings {
  viewerHotkey: HotkeyBinding;
  snippetKeyword: string;
  snippetKeywordEnabled: boolean;
  showKeywordInResult: boolean;
  matchingMode: SnippetMatchingMode;
  collections: SnippetCollection[];
}

export interface WebSearchEntry {
  id: string;
  keyword: string;
  displayText: string;
  url: string;
  isCustom: boolean;
  enabled: boolean;
  iconUrl?: string;
}

export type AppMatchingMode = 'fuzzy_capital' | 'full_fuzzy';

export interface DefaultResultsSettings {
  appMatching: AppMatchingMode;
  extensionsContacts: boolean;
  extrasEnabled: {
    folders: boolean;
    documents: boolean;
    textFiles: boolean;
    images: boolean;
    archives: boolean;
    applescript: boolean;
    customFormats: string[];
  };
  searchScope: {
    macosApplicationFolder: boolean;
    foldersInHome: boolean;
    customFolders: string[];
  };
}

export interface FileSearchSettings {
  quickSearchEnabled: boolean;
  openKeyword: string;
  findKeyword: string;
  insideKeyword: string;
  tagsKeyword: string;
  dontShow: {
    emails: boolean;
    contacts: boolean;
    calendar: boolean;
    bookmarks: boolean;
    history: boolean;
    messages: boolean;
    music: boolean;
    images: boolean;
    plistFiles: boolean;
    sourceFiles: boolean;
  };
  resultLimit: number;
  navigation: {
    fuzzyMatching: boolean;
    arrowKeysForFolders: boolean;
    enterOpensFolderInFinder: boolean;
  };
  buffer: {
    enabled: boolean;
    clearAfterAction: boolean;
    clearAfterTimeout: boolean;
  };
  advanced: {
    escapePath: boolean;
    runAppleScripts: boolean;
    useFileTypeIconsForExternal: boolean;
    touchFoldersAfterOpening: boolean;
    touchAliasesAfterOpening: boolean;
  };
}

export interface AISettings {
  provider: 'openai' | 'anthropic' | 'none';
  apiKey: string;
  model: string;
}

export interface GeneralSettings {
  launchAtLogin: boolean;
  appHotkey: HotkeyBinding;
}

export interface AppSettings {
  general: GeneralSettings;
  defaultResults: DefaultResultsSettings;
  fileSearch: FileSearchSettings;
  clipboardHistory: ClipboardHistorySettings;
  snippets: SnippetsSettings;
  webSearch: WebSearchEntry[];
  ai: AISettings;
}

export interface ClipboardItem {
  id: string;
  type: 'text' | 'image' | 'file';
  content: string;
  preview?: string;
  timestamp: number;
  wordCount?: number;
  charCount?: number;
  appIcon?: string;
  appName?: string;
}

export interface SearchResult {
  id: string;
  type: 'app' | 'file' | 'web' | 'calculator' | 'clipboard' | 'snippet' | 'system';
  title: string;
  subtitle?: string;
  icon?: string;
  iconType?: 'emoji' | 'url' | 'system';
  action?: string;
  shortcut?: string;
}
