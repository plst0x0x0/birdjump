import { create } from 'zustand';
import { persist } from 'zustand/middleware';
import type {
  AppSettings,
  ClipboardItem,
  SearchResult,
  SnippetCollection,
  WebSearchEntry,
} from '../types';

const DEFAULT_WEB_SEARCHES: WebSearchEntry[] = [
  { id: '1', keyword: 'google', displayText: "Search Google for '{query}'", url: 'https://google.com/search?q={query}', isCustom: false, enabled: true },
  { id: '2', keyword: 'lucky', displayText: "I'm feeling lucky for '{query}'", url: 'https://google.com/search?q={query}&btnI', isCustom: false, enabled: true },
  { id: '3', keyword: 'images', displayText: "Search Google Images for '{query}'", url: 'https://google.com/images?q={query}', isCustom: false, enabled: true },
  { id: '4', keyword: 'maps', displayText: "Search Google Maps for '{query}'", url: 'https://maps.google.com/?q={query}', isCustom: false, enabled: true },
  { id: '5', keyword: 'translate', displayText: "Translate '{query}'", url: 'https://translate.google.com/?q={query}', isCustom: false, enabled: true },
  { id: '6', keyword: 'gmail', displayText: 'Open Gmail', url: 'https://mail.google.com', isCustom: false, enabled: true },
  { id: '7', keyword: 'drive', displayText: 'Open Google Drive', url: 'https://drive.google.com', isCustom: false, enabled: true },
  { id: '8', keyword: 'wiki', displayText: "Search Wikipedia for '{query}'", url: 'https://en.wikipedia.org/wiki/{query}', isCustom: false, enabled: true },
  { id: '9', keyword: 'amazon', displayText: "Search Amazon for '{query}'", url: 'https://amazon.com/s?k={query}', isCustom: false, enabled: true },
  { id: '10', keyword: 'youtube', displayText: "Search YouTube for '{query}'", url: 'https://youtube.com/results?search_query={query}', isCustom: false, enabled: true },
  { id: '11', keyword: 'github', displayText: "Search GitHub for '{query}'", url: 'https://github.com/search?q={query}', isCustom: false, enabled: true },
  { id: '12', keyword: 'bing', displayText: "Search Bing for '{query}'", url: 'https://bing.com/search?q={query}', isCustom: false, enabled: true },
  { id: '13', keyword: 'linkedin', displayText: "Search LinkedIn for '{query}'", url: 'https://linkedin.com/search/results/all/?keywords={query}', isCustom: false, enabled: true },
  { id: '14', keyword: 'stackoverflow', displayText: "Search Stack Overflow for '{query}'", url: 'https://stackoverflow.com/search?q={query}', isCustom: false, enabled: true },
  { id: '15', keyword: 'imdb', displayText: "Search IMDB for '{query}'", url: 'https://imdb.com/find?q={query}', isCustom: false, enabled: true },
  { id: '16', keyword: 'ebay', displayText: "Search eBay for '{query}'", url: 'https://ebay.com/sch/i.html?_nkw={query}', isCustom: false, enabled: true },
  { id: '17', keyword: 'twitter', displayText: "Search X for '{query}'", url: 'https://x.com/search?q={query}', isCustom: false, enabled: true },
  { id: '18', keyword: 'reddit', displayText: "Search Reddit for '{query}'", url: 'https://reddit.com/search/?q={query}', isCustom: false, enabled: true },
  { id: '19', keyword: 'npmjs', displayText: "Search NPM for '{query}'", url: 'https://npmjs.com/search?q={query}', isCustom: false, enabled: true },
  { id: '20', keyword: 'wolfram', displayText: "Ask Wolfram '{query}'", url: 'https://wolframalpha.com/input?i={query}', isCustom: false, enabled: true },
];

const DEFAULT_SETTINGS: AppSettings = {
  general: {
    launchAtLogin: false,
    appHotkey: { ctrl: false, alt: false, shift: false, meta: true, key: 'Space' },
  },
  defaultResults: {
    appMatching: 'fuzzy_capital',
    extensionsContacts: false,
    extrasEnabled: {
      folders: false,
      documents: false,
      textFiles: false,
      images: false,
      archives: false,
      applescript: false,
      customFormats: [],
    },
    searchScope: {
      macosApplicationFolder: true,
      foldersInHome: false,
      customFolders: ['/', '/Applications', '~/Desktop'],
    },
  },
  fileSearch: {
    quickSearchEnabled: true,
    openKeyword: 'open',
    findKeyword: 'find',
    insideKeyword: 'in',
    tagsKeyword: 'tags',
    dontShow: {
      emails: true, contacts: true, calendar: true,
      bookmarks: true, history: true, messages: true,
      music: false, images: false, plistFiles: false, sourceFiles: false,
    },
    resultLimit: 20,
    navigation: { fuzzyMatching: true, arrowKeysForFolders: false, enterOpensFolderInFinder: false },
    buffer: { enabled: true, clearAfterAction: true, clearAfterTimeout: false },
    advanced: {
      escapePath: false, runAppleScripts: true, useFileTypeIconsForExternal: true,
      touchFoldersAfterOpening: true, touchAliasesAfterOpening: true,
    },
  },
  clipboardHistory: {
    keepPlainText: true,
    keepPlainTextDuration: '1m',
    keepImages: true,
    keepImagesDuration: '7d',
    keepFileLists: false,
    keepFileListsDuration: '24h',
    viewerHotkey: { ctrl: true, alt: true, shift: false, meta: true, key: 'C' },
    viewerKeyword: 'clipboard',
    viewerKeywordEnabled: true,
    showAllSnippetsAtTop: true,
    showSnippetsWhenSearching: true,
  },
  snippets: {
    viewerHotkey: { ctrl: false, alt: false, shift: false, meta: true, key: 'S' },
    snippetKeyword: 'snip',
    snippetKeywordEnabled: true,
    showKeywordInResult: true,
    matchingMode: 'name_keyword_snippet',
    collections: [
      {
        id: 'default',
        name: 'My Snippets',
        affix: '!',
        keyword: '',
        snippets: [
          { id: 's1', name: 'Email Signature', keyword: 'sig', content: 'Best regards,\n[Your Name]', collectionId: 'default' },
          { id: 's2', name: 'Meeting Request', keyword: 'meet', content: 'Hi, would you be available for a quick meeting this week?', collectionId: 'default' },
        ],
      },
    ],
  },
  webSearch: DEFAULT_WEB_SEARCHES,
  ai: {
    provider: 'none',
    apiKey: '',
    model: 'gpt-4o',
  },
};

interface AppState {
  settings: AppSettings;
  clipboardHistory: ClipboardItem[];
  searchQuery: string;
  searchResults: SearchResult[];
  activeWindow: 'hotkey' | 'settings' | 'clipboard' | 'snippets';
  settingsTab: string;
  settingsFeaturesTab: string;

  updateSettings: (path: string, value: unknown) => void;
  setSearchQuery: (q: string) => void;
  setSearchResults: (r: SearchResult[]) => void;
  setActiveWindow: (w: AppState['activeWindow']) => void;
  setSettingsTab: (t: string) => void;
  setSettingsFeaturesTab: (t: string) => void;
  addClipboardItem: (item: ClipboardItem) => void;
  clearClipboardHistory: () => void;
  addSnippetCollection: (col: SnippetCollection) => void;
  updateSnippetCollection: (id: string, col: Partial<SnippetCollection>) => void;
  removeSnippetCollection: (id: string) => void;
  addWebSearch: (entry: WebSearchEntry) => void;
  updateWebSearch: (id: string, entry: Partial<WebSearchEntry>) => void;
  removeWebSearch: (id: string) => void;
  addCustomFolder: (folder: string) => void;
  removeCustomFolder: (folder: string) => void;
}

export const useAppStore = create<AppState>()(
  persist(
    (set) => ({
      settings: DEFAULT_SETTINGS,
      clipboardHistory: [],
      searchQuery: '',
      searchResults: [],
      activeWindow: 'hotkey',
      settingsTab: 'General',
      settingsFeaturesTab: 'Default Results',

      updateSettings: (path, value) =>
        set((state) => {
          const keys = path.split('.');
          const newSettings = JSON.parse(JSON.stringify(state.settings));
          let obj: Record<string, unknown> = newSettings;
          for (let i = 0; i < keys.length - 1; i++) obj = obj[keys[i]] as Record<string, unknown>;
          obj[keys[keys.length - 1]] = value;
          return { settings: newSettings };
        }),

      setSearchQuery: (q) => set({ searchQuery: q }),
      setSearchResults: (r) => set({ searchResults: r }),
      setActiveWindow: (w) => set({ activeWindow: w }),
      setSettingsTab: (t) => set({ settingsTab: t }),
      setSettingsFeaturesTab: (t) => set({ settingsFeaturesTab: t }),

      addClipboardItem: (item) =>
        set((state) => ({
          clipboardHistory: [item, ...state.clipboardHistory].slice(0, 500),
        })),

      clearClipboardHistory: () => set({ clipboardHistory: [] }),

      addSnippetCollection: (col) =>
        set((state) => ({
          settings: {
            ...state.settings,
            snippets: {
              ...state.settings.snippets,
              collections: [...state.settings.snippets.collections, col],
            },
          },
        })),

      updateSnippetCollection: (id, col) =>
        set((state) => ({
          settings: {
            ...state.settings,
            snippets: {
              ...state.settings.snippets,
              collections: state.settings.snippets.collections.map((c) =>
                c.id === id ? { ...c, ...col } : c
              ),
            },
          },
        })),

      removeSnippetCollection: (id) =>
        set((state) => ({
          settings: {
            ...state.settings,
            snippets: {
              ...state.settings.snippets,
              collections: state.settings.snippets.collections.filter((c) => c.id !== id),
            },
          },
        })),

      addWebSearch: (entry) =>
        set((state) => ({
          settings: { ...state.settings, webSearch: [...state.settings.webSearch, entry] },
        })),

      updateWebSearch: (id, entry) =>
        set((state) => ({
          settings: {
            ...state.settings,
            webSearch: state.settings.webSearch.map((e) => (e.id === id ? { ...e, ...entry } : e)),
          },
        })),

      removeWebSearch: (id) =>
        set((state) => ({
          settings: {
            ...state.settings,
            webSearch: state.settings.webSearch.filter((e) => e.id !== id),
          },
        })),

      addCustomFolder: (folder) =>
        set((state) => ({
          settings: {
            ...state.settings,
            defaultResults: {
              ...state.settings.defaultResults,
              searchScope: {
                ...state.settings.defaultResults.searchScope,
                customFolders: [...state.settings.defaultResults.searchScope.customFolders, folder],
              },
            },
          },
        })),

      removeCustomFolder: (folder) =>
        set((state) => ({
          settings: {
            ...state.settings,
            defaultResults: {
              ...state.settings.defaultResults,
              searchScope: {
                ...state.settings.defaultResults.searchScope,
                customFolders: state.settings.defaultResults.searchScope.customFolders.filter(
                  (f) => f !== folder
                ),
              },
            },
          },
        })),
    }),
    { name: 'birdjump-settings' }
  )
);
