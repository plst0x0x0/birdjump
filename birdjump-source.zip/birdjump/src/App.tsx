import { useEffect } from 'react';
import { useAppStore } from './store';
import HotkeyWindow from './components/HotkeyWindow';
import SettingsWindow from './components/settings/SettingsWindow';
import ClipboardViewer from './components/ClipboardViewer';
import './App.css';

export default function App() {
  const { activeWindow, setActiveWindow } = useAppStore();

  useEffect(() => {
    const handler = (e: KeyboardEvent) => {
      if ((e.metaKey || e.ctrlKey) && e.key === ',') {
        e.preventDefault();
        setActiveWindow('settings');
      }
      if (e.key === 'Escape' && activeWindow === 'settings') {
        setActiveWindow('hotkey');
      }
    };
    window.addEventListener('keydown', handler);
    return () => window.removeEventListener('keydown', handler);
  }, [activeWindow, setActiveWindow]);

  return (
    <div className="app-container">
      {activeWindow === 'hotkey' && <HotkeyWindow />}
      {activeWindow === 'settings' && <SettingsWindow />}
      {activeWindow === 'clipboard' && <ClipboardViewer />}

      {/* Dev navigation */}
      <div className="dev-nav">
        <button onClick={() => setActiveWindow('hotkey')} className={activeWindow === 'hotkey' ? 'active' : ''}>Search</button>
        <button onClick={() => setActiveWindow('settings')} className={activeWindow === 'settings' ? 'active' : ''}>Settings</button>
        <button onClick={() => setActiveWindow('clipboard')} className={activeWindow === 'clipboard' ? 'active' : ''}>Clipboard</button>
      </div>
    </div>
  );
}
